"""
The package sorts contains different utilities for sorting

"""

from . import indexsort
from . import sorting

